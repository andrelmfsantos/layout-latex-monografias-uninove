Modelo para monografias de Doutorado (Teses) e Mestrado (Dissertação) para alunos da Universidade Nove de Julho - UNINOVE/SP.
========================================
Assista o tutorial no YouTube no Canal Fronteiras do Conhecimento (playlist: Layout para Teses & Dissertações com Overlead e LaTeX) para saber com usar e customizar esse modelo:
https://www.youtube.com/playlist?list=PLtirgjA-uMoIpAUWYt_wiU-F5e_yxJo5y
----------------------------------------
Este modelo foi desenvolvido com base no modelo do PPGI-UNINOVE, Manual de Trabalhos Acadêmicos da UNINOVE, e de acordo com as normas principais da ABNT.

Algumas adaptações de estilo foram realizadas. Assim, é importante que a pessoa que for utilizar esse modelo que verifique se atende as normas da Instituição. Posto isso, é de responsabilidade de quem for utilizar esse modelo que verifique se atende às normas da respectiva instituição.

Esse modelo foi desenvolvido para ser compilado online (direto no Overleaf), assim para executar direto na máquina será necessário pacotes adicionais.
----------------------------------------
Dúvidas, escreva para mim: André Luis M.F.Santos, andrelmfsantos@uninove.edu.br ou andrelmfsantos@gmail.com
